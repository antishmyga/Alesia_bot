import logging
import asyncio
import aiohttp
from aiogram import Bot, Dispatcher, Router
from aiogram.filters import Command
from aiogram.types import Message, CallbackQuery, FSInputFile
import config1
from keyboard import start_keyboard, menu_keyboard, coin_flip_keyboard
from weather import get_weather  # Импортируем функцию get_weather
from coin_flip_handler import handle_coin_flip  # Импортируем функцию handle_coin_flip

API_TOKEN = config1.token
DOG_API_URL = "https://api.thedogapi.com/v1/images/search"
DOG_API_KEY = "live_aTSSyyYhRv40RtEPscZop7cJjQ8RGGgxrtbzX5GzPLlHY2KclJGpda44VHU9alR2"

# Настройка ведения журнала
logging.basicConfig(level=logging.INFO)

bot = Bot(token=API_TOKEN)
dp = Dispatcher()
router = Router()

@router.message(Command("start"))
async def command_start(message: Message):
    try:
        photo = FSInputFile("/Users/alesialogvinets/Desktop/th.jpeg")
        await message.answer_photo(photo=photo, caption="Привет! Я телеграм-бот, помаши мне, если тебе интересно, что я умею", reply_markup=start_keyboard)
    except Exception as e:
        logging.error(f"Error in command_start: {e}")

@router.callback_query(lambda c: c.data == 'leave')
async def command_leave(callback_query: CallbackQuery):
    try:
        await bot.answer_callback_query(callback_query.id)
        await bot.send_message(callback_query.from_user.id, "Мне жаль прощаться с тобой так быстро, надеюсь, мы еще увидимся.")
    except Exception as e:
        logging.error(f"Error in command_leave: {e}")

@router.callback_query(lambda c: c.data == 'wave')
async def command_wave(callback_query: CallbackQuery):
    try:
        await bot.answer_callback_query(callback_query.id)
        await bot.send_message(callback_query.from_user.id, "Замечательно! Вот что я умею:", reply_markup=menu_keyboard)
    except Exception as e:
        logging.error(f"Error in command_wave: {e}")

@router.callback_query(lambda c: c.data == 'send_picture')
async def send_picture(callback_query: CallbackQuery):
    try:
        await bot.answer_callback_query(callback_query.id)
        photo_url = "https://masterpiecer-images.s3.yandex.net/962d4bfc376411eeaa96c2e644eb6d3f:upscaled"
        await bot.send_photo(callback_query.from_user.id, photo_url)
    except Exception as e:
        logging.error(f"Error in send_picture: {e}")

@router.callback_query(lambda c: c.data == 'show_dog')
async def show_dog(callback_query: CallbackQuery):
    try:
        await bot.answer_callback_query(callback_query.id)
        async with aiohttp.ClientSession(connector=aiohttp.TCPConnector(ssl=False)) as session:
            headers = {"x-api-key": DOG_API_KEY}
            async with session.get(DOG_API_URL, headers=headers) as resp:
                if resp.status == 200:
                    data = await resp.json()
                    dog_image_url = data[0]["url"]
                    await bot.send_photo(callback_query.from_user.id, dog_image_url)
                else:
                    await bot.send_message(callback_query.from_user.id, "Не удалось получить изображение собаки.")
    except Exception as e:
        logging.error(f"Error in show_dog: {e}")

@router.callback_query(lambda c: c.data == 'weather')
async def command_weather(callback_query: CallbackQuery):
    try:
        await bot.answer_callback_query(callback_query.id)
        weather_info = await get_weather()
        await bot.send_message(callback_query.from_user.id, weather_info)
    except Exception as e:
        logging.error(f"Error in command_weather: {e}")

@router.callback_query(lambda c: c.data == 'more')
async def command_more(callback_query: CallbackQuery):
    try:
        await bot.answer_callback_query(callback_query.id)
        await bot.send_message(callback_query.from_user.id, "Загадай Орел или Решка и испытай удачу", reply_markup=coin_flip_keyboard)
    except Exception as e:
        logging.error(f"Error in command_more: {e}")

@router.callback_query(lambda c: c.data in ['guess_orel', 'guess_reshka'])
async def callback_coin_flip(callback_query: CallbackQuery):
    await handle_coin_flip(callback_query, bot)

dp.include_router(router)

async def main():
    try:
        await dp.start_polling(bot)
    except Exception as e:
        logging.error(f"Error in main: {e}")

if __name__ == "__main__":
    asyncio.run(main())
