from aiogram import Bot
from aiogram.types import CallbackQuery
import logging
from coin_flip import coin_flip  # Импортируем функцию coin_flip

async def handle_coin_flip(callback_query: CallbackQuery, bot: Bot):
    try:
        user_guess = 'орел' if callback_query.data == 'guess_orel' else 'решка'
        result = coin_flip().lower()

        logging.info(f"user_guess: {user_guess}, result: {result}")

        if user_guess == 'орел' and result == 'орел':
            response = "🎲 Орел! Поздравляю, сегодня удача на твоей стороне"
        elif user_guess == 'решка' and result == 'решка':
            response = "🎲 Решка! Поздравляю, сегодня удача на твоей стороне"
        elif user_guess == 'орел' and result == 'решка':
            response = "🎲 Решка! Попробуй еще раз"
        elif user_guess == 'решка' and result == 'орел':
            response = "🎲 Орел! Попробуй еще раз"
        else:
            response = f"Произошла ошибка, попробуйте еще раз. user_guess: {user_guess}, result: {result}"

        await bot.send_message(callback_query.from_user.id, response)
    except Exception as e:
        logging.error(f"Error in handle_coin_flip: {e}")
        await bot.send_message(callback_query.from_user.id, "Произошла ошибка, попробуйте еще раз.")
