import random

def coin_flip() -> str:
    return random.choice(["орел", "решка"])
