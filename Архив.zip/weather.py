import aiohttp
import logging

API_URL = "http://api.weatherapi.com/v1/current.json"
API_KEY = "88a26623c6aa47dfa45161240241312"  # Ваш API ключ

async def get_weather(city: str = "Moscow") -> str:
    params = {
        "key": API_KEY,
        "q": city,
        "lang": "ru"
    }

    async with aiohttp.ClientSession() as session:
        try:
            async with session.get(API_URL, params=params) as response:
                if response.status == 200:
                    data = await response.json()
                    location = data["location"]["name"]
                    temperature = data["current"]["temp_c"]
                    condition = data["current"]["condition"]["text"]
                    weather_info = f"Погода в {location}: {temperature}°C, {condition}."
                    return weather_info
                else:
                    logging.error(f"Ошибка при запросе погоды: {response.status}")
                    return "Не удалось получить информацию о погоде."
        except Exception as e:
            logging.error(f"Ошибка при запросе погоды: {e}")
            return "Не удалось получить информацию о погоде."
