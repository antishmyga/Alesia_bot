# config1.py

token = "7740249053:AAG5O8So_nCApx5viPALbu7i_qA4rWEq6LI"
voice_rss_api_key = "e8aaf4b8ee5b40e3bbbbbada106633c4"
