from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton

# Начальная клавиатура
start_keyboard = InlineKeyboardMarkup(inline_keyboard=[
    [InlineKeyboardButton(text="👋", callback_data="wave"),
     InlineKeyboardButton(text="🚶", callback_data="leave")]
])

# Расширенная клавиатура
menu_keyboard = InlineKeyboardMarkup(inline_keyboard=[
    [InlineKeyboardButton(text="Улыбнись", callback_data="send_picture"),
     InlineKeyboardButton(text="Погода", callback_data="weather"),
     InlineKeyboardButton(text="Собака", callback_data="show_dog")],
    [InlineKeyboardButton(text="…", callback_data="more")]
])

# Клавиатура для игры в орел или решка
coin_flip_keyboard = InlineKeyboardMarkup(inline_keyboard=[
    [InlineKeyboardButton(text="Орел", callback_data="guess_orel"),
     InlineKeyboardButton(text="Решка", callback_data="guess_reshka")]
])
